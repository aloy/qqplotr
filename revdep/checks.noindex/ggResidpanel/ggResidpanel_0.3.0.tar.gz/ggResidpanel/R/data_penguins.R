#' Penguins Dataset
#'
#' A dataset that contains information from a study done on dives of emperor penguins by
#' Jessica Meir and others. The scientists were interested in understanding how the heart
#' rate of the penguins relates to the depth and duration of the dive. The study involved
#' attaching a device to penguins that recorded the heart rate of the bird during a dive.
#' The dataset contains multiple observations recorded from 9 penguins. The dataset has
#' 125 observations and 4 variables.
#'
#'
#' @details The variables in the dataset are as follows.
#' \tabular{ll}{
#'  \code{heartrate} \tab Heart rate of the penguin during the dive (beats per minute) \cr
#'  \code{depth} \tab Depth of the dive (meters) \cr
#'  \code{duration} \tab Duration of the dive (minutes) \cr
#'  \code{bird} \tab The id number associated with a penguin}
#'
#' @format A data.frame.
#'
#' @source \url{https://dasl.datadescription.com/datafile/penguins/?_sfm_methods=Regression&_sfm_cases=4+59943&sf_paged=9}

"penguins"
