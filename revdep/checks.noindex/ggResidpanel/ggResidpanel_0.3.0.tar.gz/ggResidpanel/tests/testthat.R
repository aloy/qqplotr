library(testthat)
library(ggResidpanel)

test_check("ggResidpanel")
