#' Deprecated functions in HLMdiag
#' 
#' These functions still work but will be removed (defunct) in the next version.
#' 
#' \itemize{
#'  \item \code{\link{HLMresid}}: This function is deprecated, and will
#'  be removed in the next version of this package.
#'  \item \code{\link{diagnostics}}: This function is deprecated, and will
#'  be removed in the next version of this package.
#' }
#' 
#' @name HLMdiag-deprecated
NULL