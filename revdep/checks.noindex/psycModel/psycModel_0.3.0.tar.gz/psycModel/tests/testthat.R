library(testthat)
library(psycModel)

test_check("psycModel")
