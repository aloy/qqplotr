#' @include modelLcmmGMM.R
setClass('lcModelLcmmGBTM', contains = 'lcModelLcmmGMM')
