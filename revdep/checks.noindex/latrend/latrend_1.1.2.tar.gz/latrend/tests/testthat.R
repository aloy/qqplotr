library(testthat)
library(latrend)
library(data.table)
library(kml)

test_check('latrend')
